Please, upload plugin files and use direct URL for features. Example: http://site.com/plugin.plg

Important: If the URL requires captcha, clicking or other interaction then it is not a direct URL and will not work.
Download must start instantly when visiting URL to plugin.